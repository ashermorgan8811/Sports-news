"""
Daily Hardwood — Auto-Updater
Runs every morning at 5:30 AM via GitHub Actions.

Fetches:
  - Real NBA scores (balldontlie.io — free)
  - Real EPL scores (TheSportsDB — free)
  - Real headlines from ESPN RSS, BBC Sport RSS, The Athletic RSS
  - Real F1 data from Ergast API (free)

Injects everything into index.html and commits.
"""

import requests, json, re, xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
from html import unescape

# ── TIMEZONE ──────────────────────────────────────────────────────────────────
ET_OFF = timezone(timedelta(hours=-4))   # EDT — GitHub Actions adjusts for DST
now_et = datetime.now(ET_OFF)
today  = now_et.strftime('%Y-%m-%d')
label  = now_et.strftime('%A, %B %-d, %Y')
doy    = int(now_et.strftime('%j'))   # day of year for shuffle seed

print(f"\n{'='*60}")
print(f"Daily Hardwood Update — {today}")
print(f"{'='*60}\n")

# ── HELPERS ───────────────────────────────────────────────────────────────────
def get(url, params=None, timeout=12):
    try:
        r = requests.get(url, params=params, timeout=timeout,
                         headers={'User-Agent': 'Mozilla/5.0 DailyHardwood/1.0'})
        return r if r.status_code == 200 else None
    except Exception as e:
        print(f"  GET failed {url[:60]}: {e}")
        return None

def clean(text):
    """Strip HTML tags and clean whitespace."""
    text = re.sub(r'<[^>]+>', ' ', text or '')
    text = unescape(text)
    return ' '.join(text.split()).strip()

def js_escape(s):
    return s.replace('\\','\\\\').replace("'","\\'").replace('\n','\\n').replace('\r','')

def short_team(n):
    table = {
        'Oklahoma City Thunder':'OKC Thunder','Golden State Warriors':'Warriors',
        'Los Angeles Lakers':'Lakers','Los Angeles Clippers':'Clippers',
        'Portland Trail Blazers':'Trail Blazers','New Orleans Pelicans':'Pelicans',
        'Memphis Grizzlies':'Grizzlies','Minnesota Timberwolves':'T-Wolves',
        'San Antonio Spurs':'Spurs','Philadelphia 76ers':'76ers',
        'Washington Wizards':'Wizards','Charlotte Hornets':'Hornets',
        'Cleveland Cavaliers':'Cavaliers','Toronto Raptors':'Raptors',
        'Milwaukee Bucks':'Bucks','Indiana Pacers':'Pacers',
        'Detroit Pistons':'Pistons','New York Knicks':'Knicks',
        'Brooklyn Nets':'Nets','Boston Celtics':'Celtics',
        'Miami Heat':'Heat','Orlando Magic':'Magic','Atlanta Hawks':'Hawks',
        'Chicago Bulls':'Bulls','Denver Nuggets':'Nuggets','Utah Jazz':'Jazz',
        'Sacramento Kings':'Kings','Phoenix Suns':'Suns',
        'Houston Rockets':'Rockets','Dallas Mavericks':'Mavericks',
    }
    return table.get(n, n)


# ════════════════════════════════════════════════════════════════════════════
#  1. FETCH NBA SCORES
# ════════════════════════════════════════════════════════════════════════════
print("📊 Fetching NBA scores...")
nba_scores = []

r = get('https://www.balldontlie.io/api/v1/games',
        params={'dates[]': today, 'per_page': 15})
if r:
    games = r.json().get('data', [])
    for g in games:
        away = short_team(g['visitor_team']['full_name'])
        home = short_team(g['home_team']['full_name'])
        status = g.get('status','')
        aS = g.get('visitor_team_score')
        hS = g.get('home_team_score')
        if status == 'Final':
            st, live = 'Final', False
        elif any(x in status for x in ['Qtr','Half','OT',"'"]):
            st, live = status, True
        else:
            try:
                dt = datetime.fromisoformat(g['date'].replace('Z','+00:00'))
                st = dt.astimezone(ET_OFF).strftime('%-I:%M %p ET')
            except:
                st = 'Tonight'
            live = False
            aS = hS = None
        nba_scores.append({'away':away,'home':home,'aS':aS,'hS':hS,'st':st,'live':live})
    print(f"  ✓ {len(nba_scores)} NBA games")
else:
    print("  ✗ NBA API unavailable — keeping existing scores")


# ════════════════════════════════════════════════════════════════════════════
#  2. FETCH EPL SCORES
# ════════════════════════════════════════════════════════════════════════════
print("\n⚽ Fetching EPL scores...")
epl_scores = []

r = get('https://www.thesportsdb.com/api/v1/json/3/eventsday.php',
        params={'d': today, 'l': 'English%20Premier%20League'})
if r:
    events = r.json().get('events') or []
    for e in events:
        home = e.get('strHomeTeam','').replace(' FC','').replace(' AFC','')
        away = e.get('strAwayTeam','').replace(' FC','').replace(' AFC','')
        status = e.get('strStatus','')
        hS_raw = e.get('intHomeScore')
        aS_raw = e.get('intAwayScore')
        if status in ('Match Finished','FT'):
            st, live = 'Final', False
            hS = int(hS_raw) if hS_raw is not None else None
            aS = int(aS_raw) if aS_raw is not None else None
        elif status in ('In Progress','HT') or "'" in status:
            st, live = status, True
            hS = int(hS_raw) if hS_raw is not None else None
            aS = int(aS_raw) if aS_raw is not None else None
        else:
            st = (e.get('strTime','') or 'TBD') + ' ET'
            live = False
            hS = aS = None
        if home and away:
            epl_scores.append({'away':away,'home':home,'aS':aS,'hS':hS,'st':st,'live':live,'lg':'EPL'})
    print(f"  ✓ {len(epl_scores)} EPL games")
else:
    print("  ✗ EPL API unavailable")


# ════════════════════════════════════════════════════════════════════════════
#  3. SCRAPE REAL HEADLINES — ESPN + BBC Sport + CBS Sports RSS
# ════════════════════════════════════════════════════════════════════════════
print("\n📰 Fetching real headlines...")

RSS_FEEDS = {
    'ESPN NBA':     'https://www.espn.com/espn/rss/nba/news',
    'ESPN NFL':     'https://www.espn.com/espn/rss/nfl/news',
    'ESPN Soccer':  'https://www.espn.com/espn/rss/soccer/news',
    'ESPN F1':      'https://www.espn.com/espn/rss/rpm/news',
    'ESPN NCAAB':   'https://www.espn.com/espn/rss/ncb/news',
    'BBC Sport':    'https://feeds.bbci.co.uk/sport/rss.xml',
    'CBS Sports':   'https://www.cbssports.com/rss/headlines/',
}

all_stories = []

for source, url in RSS_FEEDS.items():
    r = get(url)
    if not r:
        continue
    try:
        root = ET.fromstring(r.content)
        ns = {'atom': 'http://www.w3.org/2005/Atom'}
        items = root.findall('.//item')
        count = 0
        for item in items[:4]:
            title = clean(item.findtext('title',''))
            desc  = clean(item.findtext('description',''))
            link  = (item.findtext('link','') or '').strip()
            pub   = item.findtext('pubDate','')
            if not title or len(title) < 15:
                continue
            # Categorise by keywords
            t = title.lower() + ' ' + desc.lower()
            if any(x in t for x in ['nba','lakers','celtics','warriors','thunder','knicks','bucks','spurs','cavaliers','mavericks','nuggets','76ers','heat','suns','nets','bulls','pacers','pistons','grizzlies','rockets','clippers','hawks','hornets','magic','raptors','wizards','jazz','kings','blazers','pelicans','timberwolves']):
                cat = 'NBA'
            elif any(x in t for x in ['premier league','arsenal','liverpool','chelsea','man united','man city','tottenham','newcastle','everton','aston villa','brighton','fulham','west ham','wolves','leeds','crystal palace','brentford','burnley','sunderland','bournemouth','nottm','forest']):
                cat = 'EPL'
            elif any(x in t for x in ['formula 1','f1','grand prix','verstappen','hamilton','leclerc','russell','norris','alonso','ferrari','mercedes','red bull','mclaren','williams','haas']):
                cat = 'F1'
            elif any(x in t for x in ['ncaa','march madness','college basketball','duke','kansas','arizona','michigan','florida','uconn','gonzaga','houston','purdue','byu','kentucky']):
                cat = 'NCAA'
            elif any(x in t for x in ['nfl','quarterback','touchdown','super bowl','patrick mahomes','travis kelce','chiefs','eagles','cowboys','patriots','49ers','ravens','bills','bengals','browns','packers','bears','lions','vikings','rams','chargers','raiders','broncos','seahawks','cardinals','falcons','saints','buccaneers','Panthers']):
                cat = 'NFL'
            elif any(x in t for x in ['mls','soccer','world cup','champions league','la galaxy','inter miami','portland timbers','seattle sounders']):
                cat = 'Soccer'
            else:
                cat = 'Sports'
            
            all_stories.append({
                'source': source,
                'cat':    cat,
                'title':  title,
                'desc':   desc[:300] if desc else '',
                'link':   link,
                'pub':    pub,
            })
            count += 1
        if count:
            print(f"  ✓ {source}: {count} stories")
    except Exception as e:
        print(f"  ✗ {source} parse error: {e}")

print(f"  Total stories scraped: {len(all_stories)}")

# Group by category and pick best stories
by_cat = {}
for s in all_stories:
    by_cat.setdefault(s['cat'], []).append(s)

# Build the 5 lead stories for today — pick best from each sport
picked_leads = []
priority = ['NBA', 'F1', 'EPL', 'NCAA', 'NFL', 'Soccer', 'Sports']
for cat in priority:
    stories = by_cat.get(cat, [])
    if stories and len(picked_leads) < 5:
        s = stories[0]
        picked_leads.append(s)

# Also build the recap/secondary stories pool
picked_recaps = []
for cat in priority:
    stories = by_cat.get(cat, [])
    for s in stories[1:3]:  # 2nd and 3rd story per category
        if len(picked_recaps) < 8:
            picked_recaps.append(s)

print(f"\n  Leads selected: {len(picked_leads)}")
for s in picked_leads:
    print(f"    [{s['cat']}] {s['title'][:70]}")


# ════════════════════════════════════════════════════════════════════════════
#  4. BUILD JAVASCRIPT ARRAYS
# ════════════════════════════════════════════════════════════════════════════

def score_line(g, include_lg=False):
    aS = 'null' if g['aS'] is None else str(g['aS'])
    hS = 'null' if g['hS'] is None else str(g['hS'])
    live = 'true' if g.get('live') else 'false'
    lg_part = f",lg:'{g['lg']}'" if include_lg and g.get('lg') else ''
    return (f"  {{ away:'{js_escape(g['away'])}', home:'{js_escape(g['home'])}', "
            f"aS:{aS}, hS:{hS}, st:'{js_escape(g['st'])}', live:{live}{lg_part} }}")

# NBA scores JS
if nba_scores:
    new_nba_js = 'const NBA_SCORES = [\n' + ',\n'.join(score_line(g) for g in nba_scores[:8]) + '\n];'
else:
    new_nba_js = None

# EPL scores JS
if epl_scores:
    new_epl_js = 'const SOC_SCORES = [\n' + ',\n'.join(score_line(g, True) for g in epl_scores[:8]) + '\n];'
else:
    new_epl_js = None


# ── Build lead story JS array from real scraped headlines ──────────────────
def make_lead(s, idx):
    title = js_escape(s['title'])
    desc  = js_escape(s['desc'][:280]) if s['desc'] else js_escape(s['title'])
    src   = js_escape(s['source'])
    cat   = s['cat']
    date  = label

    # Map category to image query
    img_map = {
        'NBA':'basketball nba arena game action',
        'EPL':'soccer football stadium crowd match',
        'F1': 'formula 1 racing car track speed',
        'NCAA':'basketball college arena crowd',
        'NFL':'american football stadium crowd field',
        'Soccer':'soccer football stadium match',
    }
    query = img_map.get(cat, 'sports arena crowd')

    return f"""  {{
    id:'live_{idx}', tag:'{cat} · Today', date:'{date}',
    query:'{query}', seed:{idx + doy},
    headline:'{title}',
    deck:'{desc[:150].rstrip()}...',
    body:['{desc}','More details available at {src}.','Coverage courtesy of {src}.'],
    sources:[{{o:'{src}',d:'Live headline feed'}}]
  }}"""

def make_recap(s, idx):
    title = js_escape(s['title'])
    desc  = js_escape(s['desc'][:280]) if s['desc'] else ''
    src   = js_escape(s['source'])
    cat   = s['cat']
    date  = label
    img_map = {
        'NBA':'basketball game players court',
        'EPL':'soccer football match players',
        'F1': 'formula 1 racing paddock cars',
        'NCAA':'basketball college players game',
        'NFL':'american football players field',
    }
    query = img_map.get(cat, 'sports game action')
    return f"""  {{
    id:'recap_{idx}', tag:'{cat} · Recap', date:'{date}',
    query:'{query}', seed:{idx + doy + 50},
    headline:'{title}',
    teams:'', body:['{desc}'],
    km:'', sources:[{{o:'{src}',d:'Live headline'}}]
  }}"""


# ════════════════════════════════════════════════════════════════════════════
#  5. INJECT INTO index.html
# ════════════════════════════════════════════════════════════════════════════
print("\n💉 Injecting into index.html...")

with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Replace NBA scores
if new_nba_js:
    html = re.sub(r'const NBA_SCORES = \[[\s\S]*?\];', new_nba_js, html)
    print("  ✓ NBA scores updated")

# Replace EPL scores
if new_epl_js:
    html = re.sub(r'const SOC_SCORES = \[[\s\S]*?\];', new_epl_js, html)
    print("  ✓ EPL scores updated")

# Replace ALL_LEADS with today's real scraped stories (if we got enough)
if len(picked_leads) >= 3:
    leads_items = [make_lead(s, i) for i, s in enumerate(picked_leads)]
    new_leads = 'const ALL_LEADS = [\n' + ',\n'.join(leads_items) + '\n];'
    html = re.sub(r'const ALL_LEADS = \[[\s\S]*?\];', new_leads, html)
    print(f"  ✓ ALL_LEADS updated with {len(picked_leads)} real headlines")
else:
    print("  ℹ ALL_LEADS kept as-is (not enough live stories scraped)")

# Replace ALL_RECAPS with today's real scraped stories
if len(picked_recaps) >= 3:
    recap_items = [make_recap(s, i) for i, s in enumerate(picked_recaps)]
    new_recaps = 'const ALL_RECAPS = [\n' + ',\n'.join(recap_items) + '\n];'
    html = re.sub(r'const ALL_RECAPS = \[[\s\S]*?\];', new_recaps, html)
    print(f"  ✓ ALL_RECAPS updated with {len(picked_recaps)} real stories")
else:
    print("  ℹ ALL_RECAPS kept as-is")

# Update DATE_ISO so image seeds rotate
html = re.sub(
    r"const DATE_ISO\s*=\s*(?:new Date\(\)\.toISOString\(\)\.slice\(0,\s*10\)|'[0-9-]+');(?:\s*//.*)?",
    f"const DATE_ISO = '{today}'; // auto-updated {today}",
    html
)

# Update the edition label in the masthead
html = re.sub(
    r"(?<=content=\")Monday.*?(?=\" />)",
    label,
    html
)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html)

print(f"\n{'='*60}")
print(f"✅ index.html updated for {label}")
print(f"   NBA games: {len(nba_scores)}")
print(f"   EPL games: {len(epl_scores)}")
print(f"   Live headlines: {len(all_stories)}")
print(f"{'='*60}\n")
